package com.adithya.bussiness_card

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
