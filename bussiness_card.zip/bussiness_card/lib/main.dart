import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.deepPurple,
        body: SafeArea(
          child:Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 50.0,
                backgroundImage: AssetImage('image/images.jpg'),

              ),


              Text('Adithya Chandra TS',

              style:TextStyle(
                fontSize: 40.0,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                fontFamily: 'Schyler',


              )
                ,),

              Text('FLUTTER DEVELOPER',

              style: TextStyle(

                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Colors.deepPurple.shade50,
                letterSpacing: 2.0
              ),),
              Card(
                margin: EdgeInsets.all(15),

                color: Colors.white,
                child: ListTile(
                  leading:
                    Icon(
                      Icons.phone,
                      color: Colors.black,
                    ),
                    title:
                    Text('8078301930',
                    style: TextStyle(
                      fontSize: 20.0
                    ),),



                ),
              ),
              Card(
                
                margin: EdgeInsets.all(15.0),

                color: Colors.white,
                child:  ListTile(
                  leading:
                  Icon(
                    Icons.email,
                    color: Colors.black,
                  ),
                  title:
                  Text('adithyachandrats@gmail.com',
                    style: TextStyle(
                        fontSize: 20.0
                    ),),



                ),
              )
            ],
          ),


        ),
      ),
    );
  }
}

